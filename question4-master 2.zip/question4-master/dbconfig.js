const dbconfig =
{
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "que",
    port: 3306
}
module.exports = { dbconfig }